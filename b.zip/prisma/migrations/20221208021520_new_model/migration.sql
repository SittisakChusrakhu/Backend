-- DropIndex
DROP INDEX `User_Lecturer_email_key` ON `User_Lecturer`;

-- DropIndex
DROP INDEX `User_Student_student_ID_key` ON `User_Student`;

-- DropIndex
DROP INDEX `admin_email_key` ON `admin`;
