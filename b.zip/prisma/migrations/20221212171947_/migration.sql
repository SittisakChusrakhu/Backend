-- AlterTable
ALTER TABLE `Student` MODIFY `stu_id` VARCHAR(191) NOT NULL;
